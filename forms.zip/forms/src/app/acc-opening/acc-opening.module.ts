import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreationContainerComponent } from './creation-container/creation-container.component';
import {ReactiveFormsModule} from '@angular/forms';
import { FormContainerComponent } from './form-container/form-container.component';
import { DynamicFormWrapperComponent } from './form-container/dynamic-form-wrapper/dynamic-form-wrapper.component';
import { FormDataCollectorService } from './form-container/dynamic-form-wrapper/form-data-collector.service';
import { CommonUtil } from './util/app-util';

@NgModule({
  declarations: [CreationContainerComponent, FormContainerComponent,
  DynamicFormWrapperComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  providers:[FormDataCollectorService, CommonUtil]
})
export class AccOpeningModule { }
