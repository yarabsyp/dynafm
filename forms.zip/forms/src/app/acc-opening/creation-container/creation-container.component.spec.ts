import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreationContainerComponent } from './creation-container.component';

describe('CreationContainerComponent', () => {
  let component: CreationContainerComponent;
  let fixture: ComponentFixture<CreationContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreationContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreationContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
