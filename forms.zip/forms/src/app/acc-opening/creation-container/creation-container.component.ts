import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';
import { FormConfigModel, RawElement, RawElementFieldList, PurpleFieldList } from 'src/json/app-conf.model';
import { DataProvider } from 'src/json/constants.model';
import { FieldBase, Validator } from '../form-container/field-structure/fieldbase/field.base';
import { TextboxField, CheckboxField, DropdownFields, RadioField, DateField } from '../form-container/field-structure/form-fields/form-fileds.base';
import { CommonUtil } from '../util/app-util';

export class SectionWrapper {
  sectionName = '';
  labelName = '';
  childFields: Array<FieldBase<any>> = [];
  hidden :boolean = false;
  displayPreference = '';
  hasNestedGroups: boolean = false;
  childGroups: Array<GroupWrapper> = [];
}

export class GroupWrapper {
  groupName: string = '';
  hidden :boolean = false;
  displayPreference = '';
  labelName = '';
  childFields: Array<FieldBase<any>> = [];
  hasNestedGroups: boolean = false;
  nestedGroupWrappers: Array<GroupWrapper> = [];
}

@Component({
  selector: 'app-creation-container',
  templateUrl: './creation-container.component.html',
  styleUrls: ['./creation-container.component.css']
})
export class CreationContainerComponent implements OnInit {

  form: FormGroup;
  fieldConfigArrayParent: Array<SectionWrapper> = [];
  formsConfig: FormConfigModel = DataProvider.D_CONF_DATA;
  fieldMap: Map<string, string> = new Map<string, string>();
  validatorMap = new Map<string, Validator>();
  constructor(private appUtil: CommonUtil,
    private cdref: ChangeDetectorRef) {
    this.fieldMap.set('TX', 'text');
    this.fieldMap.set('TA', 'text');
    this.fieldMap.set('CB', 'checkbox');
    this.fieldMap.set('RA', 'radiobutton');
    this.fieldMap.set('DA', 'date');
    this.fieldMap.set('DT', 'date');
    this.fieldMap.set('DS', 'select');
    this.fieldMap.set('LB', 'label');
    this.fieldMap.set('MT', 'text');
    this.fieldMap.set('GR', 'group');
    this.fieldMap.set('SC', 'section');
    this.validatorMap.set('M', this.reqValidator);
    this.validatorMap.set('PR', this.reqValidator);
    this.validatorMap.set('PH', this.reqValidator);
    this.validatorMap.set('R', this.reqValidator);
    this.validatorMap.set('PM', this.reqValidator);
      
    this.appUtil.formFieldDisplayConfig = this.formFieldDisplayConfig;
    let disabledFieldNames = [];
    this.formFieldDisplayConfig.forEach((v, k) => {
      let childs = v['childs'];
      let keys = Object.keys(childs);
      keys.forEach(keyName => {
        disabledFieldNames = disabledFieldNames.concat(childs[keyName]);
      });
    });


    this.fieldConfigArrayParent.forEach(
      k => {
        k.childFields.forEach(
          childElement =>{
            if(disabledFieldNames.includes(childElement.key)){
              childElement.hidden = true;
            }
          }
        );
        k.childGroups.forEach(
          cg => {
            cg.childFields.forEach(
              cgElement =>{
                if(disabledFieldNames.includes(cgElement.key)){
                  cgElement.hidden = true;
                }
              }
            )   
          }
        );
      }
    );
  }

  parentChildValidation: Validator = {
    name: "parentChild",
    validator: this.appUtil.getValidator('parentChild'),
    message: "Invalid Parent child"
  };

  patternValidaton: Validator = {
    name: "pattern",
    validator: Validators.pattern("^[a-zA-Z]+$"),
    message: "Accept only text"
  };

   reqValidator: Validator = {
    name: "required",
    validator: Validators.required,
    message: "Name Required"
  };

  formFieldDisplayConfig: Map<string, any> = new Map<string, any>();

  ngOnInit() {
    this.formsConfig.responseMap.ConfigData.rawElements.forEach(
      relem => {
        let sectionWrapper = new SectionWrapper();
        this.processSection(relem, sectionWrapper);
        sectionWrapper.sectionName = relem.name;
        sectionWrapper.displayPreference = relem.displayPreference;
        sectionWrapper.labelName = relem.label;
        sectionWrapper.hidden = relem.displayPreference == 'PH' || relem.displayPreference == 'H';
        this.fieldConfigArrayParent.push(sectionWrapper);
      }
    );
    let fullData = DataProvider.D_CONF_DATA;

    
/*
    this.appUtil.changeField.subscribe(
      (changedField: { value: string, fieldName: string }) => {
        console.log(JSON.stringify(changedField));
        if (changedField.value && changedField.fieldName && this.formFieldDisplayConfig.get(changedField.fieldName)) {
          let childFieldsForChange = this.formFieldDisplayConfig.get(changedField.fieldName)['childs']['A'];
          let hiddenBool = !(changedField.value === 'Y');
          if (childFieldsForChange && childFieldsForChange.length > 0) {
            this.fieldConfigArrayParent.forEach(
              k => {
                k.childFields.forEach(
                  childElement =>{
                    if(childFieldsForChange.includes(childElement.key)){
                      childElement.hidden = hiddenBool;
                    }
                  }
                );
                k.childGroups.forEach(
                  cg => {
                    cg.childFields.forEach(
                      cgElement =>{
                        if(childFieldsForChange.includes(cgElement.key)){
                          cgElement.hidden = hiddenBool;
                        }
                      }
                    );
                    if(cg.hasNestedGroups){
                      this.processHideForNestedGroup(cg, childFieldsForChange);
                    }   
                  }
                );
              }
            );
          }
          this.cdref.detectChanges();
        }
      }
    );*/
    
    //this.rawElementsProcessor(fullData.responseMap.ConfigData.rawElements);
    
    this.appUtil.formFieldDisplayConfig = this.formFieldDisplayConfig;
    let disabledFieldNames = [];
    this.formFieldDisplayConfig.forEach((v, k) => {
      let childs = v['childs'];
      let keys = Object.keys(childs);
      keys.forEach(keyName => {
        disabledFieldNames = disabledFieldNames.concat(childs[keyName]);
      });
    });
    console.log('Form => ', JSON.stringify(this.fieldConfigArrayParent));
  }

  processHideForNestedGroup(cg: GroupWrapper, childFieldsForChange: Array<any>){

  }

  processSection(rawElement: RawElement, sectionWrapper: SectionWrapper) {
    rawElement.fieldList.forEach(
      flist => {
        if (flist.uiType !== 'GR') {
          let uiType = this.getType(flist.uiType);
          this.processFields(uiType, sectionWrapper, flist);
        } else {
          let childGroup = new GroupWrapper();
          this.processGroup(flist, childGroup);
          childGroup.groupName = flist.name;
          childGroup.displayPreference = flist.displayPreference;
          childGroup.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
          childGroup.labelName = flist.label;
          sectionWrapper.hasNestedGroups = true;
          sectionWrapper.childGroups.push(childGroup);
        }
      }
    );
  }

  processFields(uiType: any, fieldContainer: any, flist: any) {
   // console.log('Actual Type => ', flist.uiType);
    let fieldConfig: FieldBase<any> = null;
    let val = null;
    switch (uiType) {
      case 'text':
        fieldConfig = new TextboxField();
        fieldConfig.value = flist.defaultValue||'';
        fieldConfig.label = flist.label;
        fieldConfig.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
        fieldConfig.displayPreference = flist.displayPreference;
        fieldConfig.key = flist.name;
        val = this.validatorMap.get(fieldConfig.displayPreference);
        if(val){
          fieldConfig.validatiors.push(val);
        }
        fieldContainer.childFields.push(fieldConfig);
        break;
      case 'date':
        fieldConfig = new DateField();
        fieldConfig.value = flist.defaultValue||'';
        fieldConfig.label = flist.label;
        fieldConfig.displayPreference = flist.displayPreference;
        fieldConfig.key = flist.name;
        fieldConfig.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
        val = this.validatorMap.get(fieldConfig.displayPreference);
        if(val){
          fieldConfig.validatiors.push(val);
        }
        fieldContainer.childFields.push(fieldConfig);
        break;
      case 'checkbox':
        fieldConfig = new CheckboxField();
        fieldConfig.value = flist.defaultValue||'';
        fieldConfig.label = flist.label;
        fieldConfig.displayPreference = flist.displayPreference;
        val = this.validatorMap.get(fieldConfig.displayPreference);
        if(val){
          fieldConfig.validatiors.push(val);
        }
        fieldConfig.key = flist.name;
        fieldConfig.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
        fieldConfig.options = <Array<any>>this.formsConfig.responseMap.ConfigData.allRawAllowedValues[flist.dataSource || flist.pairInd1 || flist.pairInd2];
        fieldContainer.childFields.push(fieldConfig);
        break;
      case 'select':
        fieldConfig = new DropdownFields();
        fieldConfig.value = flist.defaultValue||'';
        fieldConfig.label = flist.label;
        fieldConfig.displayPreference = flist.displayPreference;
        fieldConfig.key = flist.name;
        val = this.validatorMap.get(fieldConfig.displayPreference);
        if(val){
          fieldConfig.validatiors.push(val);
        }
        fieldConfig.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
        fieldConfig.options = <Array<any>>this.formsConfig.responseMap.ConfigData.allRawAllowedValues[flist.dataSource || flist.pairInd1 || flist.pairInd2];
        fieldContainer.childFields.push(fieldConfig);
        break;
      case 'radiobutton':
        fieldConfig = new RadioField();
        fieldConfig.value = flist.defaultValue||'';
        fieldConfig.label = flist.label;
        fieldConfig.displayPreference = flist.displayPreference;
        fieldConfig.key = flist.name;
        val = this.validatorMap.get(fieldConfig.displayPreference);
        if(val){
          fieldConfig.validatiors.push(val);
        }
        fieldConfig.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
        fieldConfig.options = <Array<any>>this.formsConfig.responseMap.ConfigData.allRawAllowedValues[flist.dataSource || flist.pairInd1 || flist.pairInd2];
        fieldContainer.childFields.push(fieldConfig);
        break;
      default: console.log('Field Not inserted ' + flist.label + ' Type = ' + uiType);
    }
    /*if ((uiType === 'select' || uiType === 'checkbox' || uiType === 'radiobutton') && flist.refId && DataProvider.D_CONF_DATA.responseMap.ConfigData.additionalProperties['RFX_' + flist.refId]) {
      let d1 = DataProvider.D_CONF_DATA.responseMap.ConfigData.additionalProperties['RFX_' + flist.refId].split(';').filter(v => v !== '');
      if (d1 && d1.length > 0) {
        //console.log('Current Parent => ',elem.name);
        d1.forEach(element => {
          let k = element.split('=')[0];
          let v = element.split('=')[1];
          if (k == 'relatedFields') {
            v = v.replace(/'/g, '"');
            let fieldObject = JSON.parse(v);
            this.formFieldDisplayConfig.set(flist.name, { childs: fieldObject, isDisabled: false });
          }
        });
      }
      fieldConfig.validatiors.push(this.parentChildValidation);
    }*/
  }

  processGroup(rawElementFieldList: RawElementFieldList | PurpleFieldList, groupWrapper: GroupWrapper) {
    rawElementFieldList.fieldList && rawElementFieldList.fieldList.forEach(
      flist => {
        if (flist.uiType !== 'GR') {
          let uiType = this.getType(flist.uiType);
          this.processFields(uiType, groupWrapper, flist);
        } else {
          let childGroup = new GroupWrapper();
          this.processGroup(flist, childGroup);
          childGroup.groupName = flist.name;
          childGroup.labelName = flist.label;
          childGroup.displayPreference = flist.displayPreference;
          childGroup.hidden = flist.displayPreference == 'PH' || flist.displayPreference == 'H';
          groupWrapper.hasNestedGroups = true;
          groupWrapper.nestedGroupWrappers.push(childGroup);
        }
      }
    )
  }

  getType(uiType: string) {
    return this.fieldMap.get(uiType);
  }

  getInputType(inputType: string) {
    return this.fieldMap.get(inputType);
  }

  submit(event: any) {
  }
}
