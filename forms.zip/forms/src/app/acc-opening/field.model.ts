// export interface Validator {
//     name: string;
//     validator: any;
//     message: string;
// }
// export class FieldConfig {
//     label?: string;
//     name?: string;
//     inputType?: string;
//     options?: string[];
//     collections?: any;
//     type: string;
//     value?: any;
//     isBasicField: boolean = false;
//     validations?: Validator[];
// }