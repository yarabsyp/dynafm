import { Component, Input } from '@angular/core';
import { FormGroup }        from '@angular/forms';
import { FieldBase } from '../field-structure/fieldbase/field.base';
import { CommonUtil } from '../../util/app-util';

@Component({
  selector: 'dynamic-form-wrapper',
  templateUrl: './dynamic-form-wrapper.component.html'
})
export class DynamicFormWrapperComponent {
  @Input() fieldBase: FieldBase<any>;
  @Input() form: FormGroup;
  
  constructor(private commonUtil: CommonUtil) {}

  get isValid() { 
    if(!this.form.controls[this.fieldBase.key].touched){
      return true;
    }
    return this.form.controls[this.fieldBase.key].valid; 
  }


  triggerChange(event){
    //console.log('Radio Change => ', event)
    this.commonUtil.changeField.next({value:event.value, fieldName: this.fieldBase.key});
  }
}