import { Injectable } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Injectable()
export class FormDataCollectorService{
   formDataHolder: Map<string,FormGroup> = new Map<string,FormGroup>(); 

   public collectValues(sectionName: string){
    let response = {};
    this.formDataHolder.forEach(
        (v,k)=>{ 
          if(k.includes(sectionName)){
            // console.log('Group Name => ',k);
            // console.log('Submitted Value => ',v.value);
            response[k] = v.value;
          }
        }
      );
      return response;  
    }

    runValidationsForSection(sectionName){
      let sectionInvalid = false;
      let invalidGroups = [];
      this.formDataHolder.forEach(
        (v,k)=>{ 
          if(k.includes(sectionName)){
            // console.log('Group Name => ',k);
            // console.log('Submitted Value => ',v.value);
            if(v.invalid){
              sectionInvalid = true;
              invalidGroups.push(k);
              this.validateAllFormFields(v);
            }
          }
        }
      );
      return {isSectionInvalid: sectionInvalid, invalidGroupList: invalidGroups };
    }

    validateAllFormFields(formGroup: FormGroup) {
      Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        control.markAsTouched({ onlySelf: true });
      });
    } 
}