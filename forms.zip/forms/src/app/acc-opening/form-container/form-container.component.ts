import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SectionWrapper, GroupWrapper } from '../creation-container/creation-container.component';
import { FormDataCollectorService } from './dynamic-form-wrapper/form-data-collector.service';

@Component({
  selector: 'app-form-container',
  templateUrl: './form-container.component.html',
  styleUrls: ['./form-container.component.css']
})
export class FormContainerComponent implements OnInit {

  @Input() section: SectionWrapper;
  
  @Input() groupWrapper: GroupWrapper;
  @Input() isForGroup: boolean = false;

  form: FormGroup;
  @Input() parentName:string = null;
  payLoad: string = '';
  submitfnArray = [];

  constructor(private fb: FormBuilder,private formDataCollectorService:FormDataCollectorService) { }
  
  ngOnInit() {
    this.form = this.createForm();
    if(this.isForGroup){
      this.formDataCollectorService.formDataHolder.set(this.parentName+"|"+this.groupWrapper.groupName, this.form);
    }else{
      this.formDataCollectorService.formDataHolder.set(this.section.sectionName, this.form);
    }
  }

  createForm(): FormGroup{
    let group = {};
    if(!this.isForGroup){
      this.section.childFields.forEach(
        cf=> {

          group[cf.key] = this.fb.control(cf.value, this.bindValidations(cf.validatiors));
        }
      );
    } else {
      this.groupWrapper.childFields.forEach(
        cf => {
          group[cf.key] = this.fb.control(cf.value, this.bindValidations(cf.validatiors));
        }
      );
    }

    let form = this.fb.group(group);
    return form;
  }

  bindValidations(validations: any) {
    if (validations.length > 0) {
      const validList = [];
      validations.forEach(valid => {
        validList.push(valid.validator);
      });
      return Validators.compose(validList);
    }
    return null;
  }

  onSubmit() {
    let childGroupsSubmit = null;
    if(this.isForGroup!==undefined && this.isForGroup!==null && !this.isForGroup){
      let { isSectionInvalid, invalidGroupList } = this.formDataCollectorService.runValidationsForSection(this.section.sectionName);
      if(!isSectionInvalid){
        childGroupsSubmit = this.formDataCollectorService.collectValues(this.section.sectionName);
      }
    }

    if(this.form && this.form.invalid){
      this.formDataCollectorService.validateAllFormFields(this.form);
    }

    let resp ={};
    if(childGroupsSubmit){
      resp['cgroups'] = childGroupsSubmit;
    }
    resp['parent'] = this.form.value;   
    this.payLoad = JSON.stringify(resp);
    console.log('Submitted value => ', this.payLoad)
  }
}
