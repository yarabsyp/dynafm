import { FormControl } from "@angular/forms";
import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable()
export class CommonUtil {
    
    changeField: Subject<any> = new Subject<any>();
    
    private fieldValidatorFunctionMap:Map<string, any>;   
    formFieldDisplayConfig: Map<string,any> =  new Map<string, any>();

    constructor(){ 
         this.fieldValidatorFunctionMap = new Map<string, any>();
         this.fieldValidatorFunctionMap.set('age', this.ageValidator);
         //this.fieldValidatorFunctionMap.set('name', this.lenValidator);
         this.fieldValidatorFunctionMap.set('elsner', this.elsner);
         this.fieldValidatorFunctionMap.set('umaname', this.dinesh);
         this.fieldValidatorFunctionMap.set('state', this.yarab);
         this.fieldValidatorFunctionMap.set('parentChild', this.parentChildValidation);
     }

     private ageValidator(control: FormControl) { 
        //  debugger;
        let controlValue = control.value;
        if (controlValue <18)
            return null;
        return controlValue; 
    }

    private address(control: FormControl):{[key: string]: any} | null { 
        // debugger;
        let controlValue = control.value;
        if (controlValue && controlValue.length < 10)
            return {'lesserValue': {value: control.value}};
        return null; 
    }

    private elsner(control: FormControl):{[key: string]: any} | null {
        console.log('trigged elsners methos');
        return null; 
    }

    private dinesh(control: FormControl):{[key: string]: any} | null {
        console.log('trigged uma element methos');
        return null; 
    }
    private yarab(control: FormControl):{[key: string]: any} | null {
        console.log('You have seledted  '+control.value);
        return null; 
    }

    private parentChildValidation(control: FormControl):{[key: string]: any} | null {
        //console.log("parent child field trigger",JSON.stringify(control));
        return null;
    }

    public getValidator(key: string): any{
        return this.fieldValidatorFunctionMap.get(key);
    }
}