import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreationContainerComponent } from './acc-opening/creation-container/creation-container.component';

const routes: Routes = [
  { path:'open', component: CreationContainerComponent},
  { path:'**', component: CreationContainerComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
