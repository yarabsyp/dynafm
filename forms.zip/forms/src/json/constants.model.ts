
// import { ConfigData } from "../util/configClass";
import { CONF_DATA } from "./constants_new.model";
import { FormConfigModel } from "./app-conf.model";

export namespace DataProvider{

  export const D_CONF_DATA:FormConfigModel = CONF_DATA;

}